package datos;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;
import modelos.Employees;
import tbd.FrmMenu;
import tbd.FrnInicio;
import modelos.Info;

public class DAOEmployees {


    public Employees Login(String User, String Pass) throws Exception {
        try {
            FrnInicio objF = new FrnInicio();
            if (Conexion.conectar()) {
                PreparedStatement ps = Conexion.conexion.prepareStatement("SELECT Usuario, Pass FROM Employees WHERE Usuario=? and Pass=sha1(?)");
                ps.setString(1, User);
                ps.setString(2, Pass);
                ps.execute();
                ResultSet rsLista = ps.executeQuery();

                if (rsLista.next()) {
                    JOptionPane.showMessageDialog(objF, "Bienvenido: " + User);
                    objF.setVisible(false);
                    new FrmMenu().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(objF, "Error de inicio");
                    objF.setVisible(true);
                }
                return null;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }
    
    public int agregar(Employees objE) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "INSERT INTO Employees(EmployeeID, LastName, FirstName, Title, Usuario, Pass)"
                        + " VALUES(default,?,?,?,?,sha1(?))";
                PreparedStatement sentencia = Conexion.conexion.prepareStatement(sql,
                        PreparedStatement.RETURN_GENERATED_KEYS);
                sentencia.setString(1, objE.getLastname());
                sentencia.setString(2, objE.getFirsttname());
                sentencia.setString(3, objE.getTitle());
                sentencia.setString(4, objE.getUsuario());
                sentencia.setString(5, objE.getPass());
                sentencia.executeUpdate();
                ResultSet rsClaves = sentencia.getGeneratedKeys();

                if (rsClaves.next()) {
                    return rsClaves.getInt(1);
                } else {
                    return 0;
                }

            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1451) {
                throw new Exception("Error al intentar añadir este producto a una categoría o proveedor que no existen");
            }
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }

    public boolean editar(Employees objE) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "{ call paEmpleadoActualizar(?,?,?,?,?,?)}";
                CallableStatement sentencia = Conexion.conexion.prepareCall(sql);
                sentencia.setInt(1, objE.getId());
                sentencia.setString(2, objE.getLastname());
                sentencia.setString(3, objE.getFirsttname());
                sentencia.setString(4, objE.getTitle());
                sentencia.setString(5, objE.getUsuario());
                sentencia.setString(6, objE.getPass());
                int filasAfectadas = sentencia.executeUpdate();
                return filasAfectadas > 0;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1451) {
                throw new Exception("Error al intentar añadir este producto a una categoría o proveedor que no existen");
            }
            throw new Exception("No se ha podido realizar la operación Editar");
        } finally {
            Conexion.desconectar();
        }
    }

    public boolean eliminar(int id) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "DELETE FROM Employees"
                        + " WHERE EmployeeID = ?";
                PreparedStatement sentencia = Conexion.conexion.prepareStatement(sql);
                sentencia.setInt(1, id);

                if (sentencia.executeUpdate() > 0) {
                    return true;
                } else {
                    return false;
                }

            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1451) {
                throw new Exception("No se puede eliminar un Empleado que tiene historial de ventas");
            }
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }

    public ArrayList<Employees> consultarTodos() throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT e.EmployeeID Clave, e.FirstName Nombre, e.LastName Apellido,"
                        + "    e.Title Puesto, e.Usuario Usuario,"
                        + "    e.Pass Contrasenia "
                        + " FROM Employees e;";
                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);
                ArrayList<Employees> listaEmpleados = new ArrayList<>();
                while (rsLista.next()) {
                    Employees objE = new Employees(
                            rsLista.getInt("Clave"),
                            rsLista.getString("Nombre"),
                            rsLista.getString("Apellido"),
                            rsLista.getString("Puesto"),
                            rsLista.getString("Usuario"),
                            rsLista.getString("Contrasenia"));
                    listaEmpleados.add(objE);
                }
                return listaEmpleados;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            System.out.println("Mamaste todo");
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }
    public Employees consultarUno(int id) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT EmployeeID, LastName, "
                        + "FirstName, Title, Usuario, Pass "
                        + "FROM Employees WHERE EmployeeID =" + id;
                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);

                if (rsLista.next()) {
                    return new Employees(
                            rsLista.getInt("EmployeeID"),
                            rsLista.getString("LastName"),
                            rsLista.getString("FirstName"),
                            rsLista.getString("Title"),
                            rsLista.getString("Usuario"),
                            rsLista.getString("Pass"));
                }
                return null;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }

    public void titulo(String tit) {
        try {
            String title = tit;
            if (Conexion.conectar()) {
                Statement consulta = (Statement) Conexion.conexion.createStatement();
                ResultSet resultado = consulta.executeQuery("select * from employees where usuario ='" + title+ "';");
                int columna_tipo = resultado.findColumn("Title");
                boolean lleno = resultado.next();
                while (lleno) {
                    Info.title = resultado.getString(columna_tipo);
                    lleno = resultado.next();
                }
            }
        } catch (Exception e) {
            System.err.println("Error en abrir la conexión");
            System.err.println("ERROR:" + e.getMessage());
            System.exit(0);
        }
    }

}
