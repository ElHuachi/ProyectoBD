/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import datos.Conexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import javax.swing.JOptionPane;
import modelos.Producto;
import modelos.Ventas;

public class DAOVentas {

    public double PyS(String N) {
        double precio = 0;
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT UNITPRICE FROM Products WHERE Productname =" + "'" + N + "'";
                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);
                while (rsLista.next()) {
                    precio = rsLista.getDouble("UNITPRICE");
                }
                return precio;
            }
        } catch (Exception e) {
        }
        return precio;
    }
    
    public boolean agregarVarios(List<Ventas> ventas) throws Exception {
        try {
            if (Conexion.conectarTrans()) {
                for(Ventas venta : ventas)
                {
                    String sql = "INSERT INTO Orderdetails(Orderid,ProducTid,Unitprice,Quantity)"
                            + " VALUES(?,?,?,?)";
                    PreparedStatement sentencia = Conexion.conTrans.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
                    sentencia.setInt(1, DAOOrdenes.UltimaO());
                    sentencia.setInt(2, (int) DAOVentas.IdProduct(venta.getProducto()));
                    sentencia.setDouble(3, venta.getPrecio());
                    sentencia.setDouble(4, venta.getCantidad());
                    sentencia.executeUpdate();
                }
                Conexion.conTrans.commit();
                return true;
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Llave primaria duplicada");
            Conexion.conTrans.rollback();
            return false;
        }
        return false;
        
    }

    public static double IdProduct(String N) {
        double id = 0;
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT Productid FROM Products WHERE Productname =" + "'" + N + "'";
                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);
                while (rsLista.next()) {
                    id = rsLista.getDouble("Productid");
                }
                return id;
            }
        } catch (Exception e) {
        }
        return id;
    }

    public int agregar(Ventas Ventas) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "INSERT INTO Orderdetails(Orderid,ProducTid,Unitprice,Quantity)"
                        + " VALUES(?,?,?,?)";
                PreparedStatement sentencia = Conexion.conexion.prepareStatement(sql,
                        PreparedStatement.RETURN_GENERATED_KEYS);
                sentencia.setInt(1, DAOOrdenes.UltimaO());
                sentencia.setInt(2, (int) DAOVentas.IdProduct(Ventas.getProducto()));
                sentencia.setDouble(3, Ventas.getPrecio());
                sentencia.setDouble(4, Ventas.getSubtotal());
                sentencia.executeUpdate();


            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
          return -1;
    }
}
