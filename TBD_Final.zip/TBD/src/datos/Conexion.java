/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import com.mysql.cj.exceptions.MysqlErrorNumbers;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author paveg
 */
public class Conexion {

    static Connection conexion, conTrans;
    
    private static String sqlCon = "jdbc:mysql://localhost:3308"
                            + "/northwind?"
                            + "user=root&password=Rec159432@";

    public static boolean conectar() {
        try {
            conexion = DriverManager.getConnection(sqlCon);

            return true;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }
    
    public static boolean conectarTrans() {
        try {
            conTrans = DriverManager.getConnection(sqlCon);
            conTrans.setAutoCommit(false);
            
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public static void desconectar() {
        try {
            conexion.close();
        } catch (Exception ex) {
        }
    }

}
