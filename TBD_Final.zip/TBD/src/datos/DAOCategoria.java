/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import com.mysql.cj.exceptions.MysqlErrorNumbers;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelos.Categoria;
import modelos.Info;

/**
 * DataAccessObject
 *
 * @author paveg
 */
public class DAOCategoria {

    public ArrayList<Categoria> consultarTodos() throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT CategoryId, Categoryname"
                        + " FROM categories"
                        + " ORDER BY 2;";

                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);
                ArrayList<Categoria> lista = new ArrayList<>();
                while (rsLista.next()) {
                    Categoria objCategoria = new Categoria(
                            rsLista.getInt("CategoryID"),
                            rsLista.getString("CategoryName"));
                    lista.add(objCategoria);
                }
                return lista;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }

    public boolean eliminar(int id) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "DELETE FROM Categories"
                        + " WHERE CategoryID = ?";
                PreparedStatement sentencia = Conexion.conexion.prepareStatement(sql);
                sentencia.setInt(1, id);

                if (sentencia.executeUpdate() > 0) {
                    return true;
                } else {
                    return false;
                }

            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1451) {
                throw new Exception("No se puede eliminar una categoria que tiene historial de ventas");
            }
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }

    public Categoria consultarUno(int id) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT CategoryID, CategoryName, "
                        + "`Description` "
                        + "FROM Categories WHERE CategoryID =" + id;
                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);

                if (rsLista.next()) {
                    return new Categoria(
                            rsLista.getInt("CategoryID"),
                            rsLista.getString("CategoryName"),
                            rsLista.getString("Description"));
                }
                return null;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }

    public boolean editar(Categoria objE) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "{ call paCategoriaActualizar(?,?,?)}";
                CallableStatement sentencia = Conexion.conexion.prepareCall(sql);
                sentencia.setInt(1, objE.getIdCategoria());
                sentencia.setString(2, objE.getCategoria());
                sentencia.setString(3, objE.getDescription());
                int filasAfectadas = sentencia.executeUpdate();
                return filasAfectadas > 0;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1451) {
                throw new Exception("Error al intentar añadir este producto a una categoría o proveedor que no existen");
            }
            throw new Exception("No se ha podido realizar la operación" + " DAOE");
        } finally {
            Conexion.desconectar();
        }
    }
    public int agregar(Categoria objE) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "INSERT INTO Categories(CategoryID, CategoryName, Description)"
                        + " VALUES(default,?,?)";
                PreparedStatement sentencia = Conexion.conexion.prepareStatement(sql,
                        PreparedStatement.RETURN_GENERATED_KEYS);
                sentencia.setString(1, objE.getCategoria());
                sentencia.setString(2, objE.getDescription());
                sentencia.executeUpdate();
                ResultSet rsClaves = sentencia.getGeneratedKeys();
                if (rsClaves.next()) {
                    return rsClaves.getInt(1);
                } else {
                    return 0;
                }
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1451) {
                throw new Exception("Error al intentar añadir esta categoría");
            }
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }
    
        public void Name(String name) {
        try {
            String prod = name;
            if (Conexion.conectar()) {
                Statement consulta = (Statement) Conexion.conexion.createStatement();
                ResultSet resultado = consulta.executeQuery("select * from categories where CategoryName ='" + prod + "';");
                int columna_tipo = resultado.findColumn("CategoryName");
                boolean lleno = resultado.next();
                while (lleno) {
                    Info.categoria = resultado.getString(columna_tipo);
                    lleno = resultado.next();
                }
            }
        } catch (Exception e) {
            System.out.println("Limpio");
        }
    }

}
