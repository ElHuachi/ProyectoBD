/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelos.Ordenes;
import modelos.Ventas;

public class DAOOrdenes {

    public static int orden;

    public ArrayList<Ordenes> consultarTodos() throws Exception {
        String sql = "SELECT Orderid,Customerid,"
                + "    Employeeid,Orderdate FROM Orders order by OrderDate desc";
        try {
            if (Conexion.conectar()) {

                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);
                ArrayList<Ordenes> ListaOrdenes = new ArrayList<>();
                while (rsLista.next()) {
                    Ordenes objP = new Ordenes(
                            rsLista.getInt("Orderid"),
                            rsLista.getString("CustomerID"),
                            rsLista.getInt("Employeeid"),
                            rsLista.getString("Orderdate"));
                    ListaOrdenes.add(objP);
                }
                return ListaOrdenes;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }

    }

    public static int UltimaO() throws SQLException {
        try {
            if (Conexion.conectar()) {
                String sql2 = " SELECT MAX(orderid) from orders";
                Statement consulta1 = Conexion.conexion.createStatement();
                ResultSet rs = consulta1.executeQuery(sql2);
                if (rs.next()) {
                    orden = rs.getInt(1);
                } else {
                    orden = -1;
                }
            } else {
                JOptionPane.showMessageDialog(null, "NO JALO1");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "NO JALO");
        }
        return orden;
    }

    public ArrayList<Ventas> consultarTodosDetalles(int id) throws Exception {
        try {
            if (Conexion.conectar()) {
                String sql = "SELECT p.Productname,o.Unitprice,o.Quantity, round(o.UnitPrice*o.Quantity,3) Subtotal FROM OrderDetails o join products p using(Productid)"
                        + "                  where orderid =" + id + " group by productname";

                Statement consulta = Conexion.conexion.createStatement();
                ResultSet rsLista = consulta.executeQuery(sql);
                ArrayList<Ventas> ListaOrdenes = new ArrayList<>();
                while (rsLista.next()) {
                    Ventas objP = new Ventas(
                            rsLista.getString("Productname"),
                            rsLista.getDouble("Unitprice"),
                            rsLista.getInt("Quantity"),
                            rsLista.getDouble("Subtotal"));
                    ListaOrdenes.add(objP);
                }
                return ListaOrdenes;
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
    }
 
public int agregar(Ordenes objOrden) throws Exception {
         try {
             if (Conexion.conectar()) {
                String sql = "INSERT INTO Orders(Orderid,CustomerID,Employeeid,Orderdate,shippeddate,shipvia,shipPostalCode)" +
                            " VALUES(?,?,?,?,?,?,?)";
                PreparedStatement sentencia = Conexion.conexion.prepareStatement(sql);
                sentencia.setInt(1, objOrden.getId());
                sentencia.setString(2, objOrden.getCustomerid());
                sentencia.setInt(3, objOrden.getEmployeid());
                sentencia.setString(4, objOrden.getFecha());
                sentencia.setString(5, objOrden.getShippdate());
                sentencia.setInt(6, objOrden.getShipvia());
                sentencia.setString(7, objOrden.getShippostalcode());
                
                sentencia.executeUpdate();
//              
            } else {
                throw new Exception("No se ha podido conectar con el servidor");
            }
        } catch (SQLException ex) {
            if(ex.getErrorCode()==1451){
                throw new Exception("Error al intentar añadir este producto a una categoría o proveedor que no existen");
            }
            throw new Exception("No se ha podido realizar la operación");
        } finally {
            Conexion.desconectar();
        }
  return 0;
    }


}
