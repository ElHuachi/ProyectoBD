package modelos;
public class Ordenes {

    private int id;
    private String Customerid;
    private int Employeid;
    private String fecha;
    private String shippdate;
    private int shipvia;
    private String shippostalcode;

    public Ordenes(String Customerid, int Employeid, String fecha, String shippdate, int shipvia, String shippostalcode) {
        this.Customerid = Customerid;
        this.Employeid = Employeid;
        this.fecha = fecha;
        this.shippdate = shippdate;
        this.shipvia = shipvia;
        this.shippostalcode = shippostalcode;
    }

    public Ordenes(int id, String Customerid, int Employeid, String fecha) {
        this.id = id;
        this.Customerid = Customerid;
        this.Employeid = Employeid;
        this.fecha = fecha;
    }

    public Ordenes(int id, String Customerid, int Employeid, String fecha, String shippdate, int shipvia, String shippostalcode) {
        this.id = id;
        this.Customerid = Customerid;
        this.Employeid = Employeid;
        this.fecha = fecha;
        this.shippdate = shippdate;
        this.shipvia = shipvia;
        this.shippostalcode = shippostalcode;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerid() {
        return Customerid;
    }

    public void setCustomerid(String Customerid) {
        this.Customerid = Customerid;
    }

    public int getEmployeid() {
        return Employeid;
    }

    public void setEmployeid(int Employeid) {
        this.Employeid = Employeid;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getShippdate() {
        return shippdate;
    }

    public void setShippdate(String shippdate) {
        this.shippdate = shippdate;
    }

    public int getShipvia() {
        return shipvia;
    }

    public void setShipvia(int shipvia) {
        this.shipvia = shipvia;
    }

    public String getShippostalcode() {
        return shippostalcode;
    }

    public void setShippostalcode(String shippostalcode) {
        this.shippostalcode = shippostalcode;
    }

}
